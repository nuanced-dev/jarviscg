A key value is imported from an external module and used to access a function
stored in a dictionary.

def func1():
    pass

def func2():
    pass

d = {1: func1, "1": func2}

d[1]()

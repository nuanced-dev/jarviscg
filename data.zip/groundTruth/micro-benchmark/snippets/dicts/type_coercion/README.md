Check if a call graph generator type coerces integer and string values.

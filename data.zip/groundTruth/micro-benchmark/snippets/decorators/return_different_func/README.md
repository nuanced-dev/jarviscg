A decorator returns a different function than that assigned to it.
When Python interprets functions with decorators it calls the decorator
before actually executing the function.
That's why an edge appears from "main" to "main.dec".

A simple function with a decorator.

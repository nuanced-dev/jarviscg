def func():
    print(1)
    pass

eval("func()")

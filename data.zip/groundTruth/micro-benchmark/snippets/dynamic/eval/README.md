A function is called using eval.

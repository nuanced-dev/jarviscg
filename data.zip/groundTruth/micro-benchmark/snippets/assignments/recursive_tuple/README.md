Three variables are assigned a value via a recursive tuple assignment.

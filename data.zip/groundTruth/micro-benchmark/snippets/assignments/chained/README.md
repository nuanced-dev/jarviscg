Two variables are assigned a function via chained assignment.

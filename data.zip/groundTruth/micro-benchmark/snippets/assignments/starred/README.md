Functions are assigned to variables via starred assignment

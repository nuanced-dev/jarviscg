A class is instantiated and we call one of its functions. The function called
assigns `self` to a variable and using that variable we call a different
function contained in the class.

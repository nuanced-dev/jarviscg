A method returns a different method and that method is directly called.

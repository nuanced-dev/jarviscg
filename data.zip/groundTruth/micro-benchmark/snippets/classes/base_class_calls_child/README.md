The base class calls a function defined by the child class.

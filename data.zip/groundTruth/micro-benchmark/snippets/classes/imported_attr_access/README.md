A module is imported and a function it defines is called.

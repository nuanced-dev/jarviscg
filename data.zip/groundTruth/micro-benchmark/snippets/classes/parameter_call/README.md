A class method is assigned parameters which are called.

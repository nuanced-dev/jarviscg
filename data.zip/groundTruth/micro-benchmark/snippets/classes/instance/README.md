A class is instantiated and we check whether an edge is created to its `__init__`
function.

class MyClass:
    def __init__(self):
        pass

    def func(self):
        pass

a = MyClass()
a.func()

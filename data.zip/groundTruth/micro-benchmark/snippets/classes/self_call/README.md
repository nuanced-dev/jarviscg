A function is called inside a class using self.

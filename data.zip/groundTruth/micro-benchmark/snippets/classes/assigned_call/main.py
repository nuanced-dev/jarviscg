class MyClass:
    def __init__(self) -> None:
        pass
    def func(self):
        pass

a = MyClass()
b = a.func
b()

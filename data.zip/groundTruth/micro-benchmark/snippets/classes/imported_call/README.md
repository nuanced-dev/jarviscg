A class is imported from a different module and then instantiated. We call one
of its functions.

class MyClass:
    def __init__(self) -> None:
        pass
    def func(self):
        pass

a = MyClass()
a.func()

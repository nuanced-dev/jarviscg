A class is instantiated and its function is called.

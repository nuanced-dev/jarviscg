We perform tuple assignment on class methods.

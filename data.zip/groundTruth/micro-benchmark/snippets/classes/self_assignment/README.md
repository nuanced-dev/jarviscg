A function is assigned as a self attribute.

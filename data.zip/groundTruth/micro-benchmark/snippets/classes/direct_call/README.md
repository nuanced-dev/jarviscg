A class is instantiated and then its function is called directly after the
instantiation.

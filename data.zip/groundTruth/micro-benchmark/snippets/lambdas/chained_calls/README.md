Lambdas are passed via parameters to chained functions and then called.

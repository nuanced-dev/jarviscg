A parameter is used to index a list.

A function is used for the value of a comprehension.

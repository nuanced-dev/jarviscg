A key is imported from an external source and used to index a list.
